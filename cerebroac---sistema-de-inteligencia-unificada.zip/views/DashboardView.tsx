
import React, { useState } from 'react';
import { KPI_STATS, RECENT_ALERTS, MOCK_PROJECTS } from '../constants';
import { useGlobalState } from '../components/GlobalState';
import { Project } from '../types';

export const DashboardView: React.FC = () => {
  const { navigate, addProject, addNotification } = useGlobalState();
  const [showCreateOpModal, setShowCreateOpModal] = useState(false);
  const [newOpData, setNewOpData] = useState({ title: '', type: 'Microtráfico', zone: '' });
  const [isGeocoding, setIsGeocoding] = useState(false);

  const handleCreateOperation = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newOpData.title || !newOpData.zone) return;

    setIsGeocoding(true);

    try {
       // 1. Precision Geocoding (Pre-flight)
       const response = await fetch(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(newOpData.zone)}&limit=1`);
       const geoData = await response.json();

       let coords = { lat: -32.94682, lng: -60.63932 }; // Fallback (Rosario)
       let zoomLevel = 13;

       if (geoData && geoData.length > 0) {
          coords = {
             lat: parseFloat(geoData[0].lat),
             lng: parseFloat(geoData[0].lon)
          };
          zoomLevel = 16; // High precision zoom
          addNotification('success', `Coordenadas fijadas: ${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}`);
       } else {
          addNotification('warning', 'Ubicación exacta no encontrada. Usando aproximación regional.');
       }

       // 2. Create Project Context
       const newProject: Project = {
         id: `op-${Date.now()}`,
         title: newOpData.title,
         type: newOpData.type as any,
         location: newOpData.zone,
         status: 'Active',
         lastUpdate: 'Recién creado',
         members: ['u-001'],
         thumbnail: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/12/2485/1376',
         progress: 0,
         entityCount: 0
       };

       addProject(newProject);
       setShowCreateOpModal(false);
       
       // 3. Tactical Deployment (Navigate with Params)
       navigate('map', { 
          center: [coords.lat, coords.lng], 
          zoom: zoomLevel,
          deployMarker: true,
          label: `OP: ${newOpData.title}`
       });

    } catch (error) {
       console.error("Geocoding error", error);
       addNotification('error', 'Error de conexión con satélite de mapas.');
       setIsGeocoding(false);
    }
  };

  return (
    <div className="p-8 h-full overflow-y-auto custom-scrollbar bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-nexus-900 via-nexus-950 to-black">
      
      {/* Header Section */}
      <div className="flex justify-between items-end mb-8 relative z-10">
         <div>
            <h1 className="text-4xl font-black text-white tracking-tighter flex items-center gap-3">
               CEREBRO<span className="text-nexus-accent">AC</span>
               <span className="text-xs font-mono font-normal text-gray-500 bg-nexus-900 border border-nexus-800 px-2 py-1 rounded-full tracking-widest uppercase">
                  v4.2.0 Stable
               </span>
            </h1>
            <p className="text-sm text-gray-400 mt-2 max-w-xl">
               Centro de Comando Unificado para operaciones de inteligencia criminal y despliegue táctico.
            </p>
         </div>
         <div className="flex gap-3">
            <div className="text-right hidden md:block">
               <div className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Nivel de Amenaza</div>
               <div className="text-xl font-black text-nexus-warning flex items-center justify-end gap-2">
                  <span className="w-3 h-3 bg-nexus-warning rounded-full animate-pulse"></span>
                  ELEVADO (DEFCON 3)
               </div>
            </div>
         </div>
      </div>

      {/* KPI Stats Row - Modernized */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8 relative z-10">
        {KPI_STATS.map((stat, idx) => (
          <div key={idx} className="glass-panel border border-nexus-800/50 rounded-xl p-5 relative overflow-hidden group hover:border-nexus-600 transition-all duration-300">
            <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity transform group-hover:scale-110 duration-500">
               <span className="material-symbols-outlined text-6xl text-white">{stat.icon}</span>
            </div>
            <div className="relative z-10">
               <div className="flex justify-between items-start mb-2">
                  <div className={`p-2 rounded-lg ${stat.positive ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                     <span className="material-symbols-outlined text-xl">{stat.icon}</span>
                  </div>
                  <span className={`text-[10px] font-bold px-2 py-1 rounded-full flex items-center gap-1 ${stat.positive ? 'text-emerald-400 bg-emerald-500/5' : 'text-rose-400 bg-rose-500/5'}`}>
                    {stat.positive ? '▲' : '▼'} {stat.change}
                  </span>
               </div>
               <div className="text-3xl font-black text-white mb-1 tracking-tight">{stat.value}</div>
               <div className="text-xs text-gray-500 font-bold uppercase tracking-wider">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-12 gap-8 relative z-10">
         
         {/* MAIN FEATURE: Interactive Map Command Center */}
         <div className="col-span-12 lg:col-span-8 h-[600px] rounded-2xl overflow-hidden relative shadow-2xl border border-nexus-700 group">
            {/* Live Map Background (Simulated) */}
            <div className="absolute inset-0 bg-nexus-900">
               <div className="absolute inset-0 bg-cover bg-center opacity-60 transition-transform duration-[20s] ease-linear group-hover:scale-105" style={{ backgroundImage: 'url(https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/12/2485/1376)' }}></div>
               
               {/* UI Overlays */}
               <div className="absolute inset-0 bg-gradient-to-t from-nexus-950 via-nexus-900/20 to-transparent"></div>
               <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,transparent_0%,#0f172a_120%)]"></div>
               
               {/* Grid Lines */}
               <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.03)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.03)_1px,transparent_1px)] bg-[size:40px_40px]"></div>
            </div>

            {/* Central Command UI */}
            <div className="absolute inset-0 flex flex-col items-center justify-center p-8 text-center z-20">
               <div className="w-24 h-24 rounded-full border-2 border-nexus-accent/30 flex items-center justify-center bg-nexus-900/80 backdrop-blur-md shadow-[0_0_50px_rgba(37,99,235,0.2)] mb-6 animate-pulse-slow">
                  <span className="material-symbols-outlined text-5xl text-nexus-accent">travel_explore</span>
               </div>
               
               <h2 className="text-4xl font-black text-white tracking-tight mb-2 drop-shadow-lg">SALA DE SITUACIÓN</h2>
               <p className="text-gray-300 max-w-lg mb-10 text-sm font-medium drop-shadow-md">
                  Visualización geoespacial activa. Monitoreo de objetivos en tiempo real, zonas calientes y despliegue de unidades.
               </p>

               <div className="flex gap-4">
                  <button 
                     onClick={() => setShowCreateOpModal(true)}
                     className="group relative px-8 py-4 bg-nexus-accent hover:bg-blue-600 text-white rounded-xl font-bold shadow-lg shadow-blue-900/40 transition-all overflow-hidden"
                  >
                     <div className="absolute inset-0 bg-white/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300"></div>
                     <span className="relative flex items-center gap-3">
                        <span className="material-symbols-outlined">add_location_alt</span>
                        INICIAR NUEVA OPERACIÓN
                     </span>
                  </button>
                  
                  <button 
                     onClick={() => navigate('map')}
                     className="px-8 py-4 bg-nexus-900/60 hover:bg-nexus-800 text-white border border-nexus-600 hover:border-nexus-400 rounded-xl font-bold backdrop-blur-md transition-all flex items-center gap-3"
                  >
                     <span className="material-symbols-outlined">map</span>
                     ACCEDER AL VISOR
                  </button>
               </div>
            </div>

            {/* Live Indicators Corner */}
            <div className="absolute top-6 left-6 flex items-center gap-3 bg-black/60 backdrop-blur px-3 py-1.5 rounded-lg border border-white/10">
               <div className="relative w-3 h-3">
                  <span className="absolute inline-flex h-full w-full rounded-full bg-red-500 opacity-75 animate-ping"></span>
                  <span className="relative inline-flex rounded-full h-3 w-3 bg-red-600"></span>
               </div>
               <span className="text-[10px] font-mono font-bold text-white tracking-widest">SATÉLITE EN VIVO</span>
            </div>

            {/* Bottom Bar Info */}
            <div className="absolute bottom-0 left-0 right-0 h-16 bg-nexus-900/90 backdrop-blur border-t border-nexus-700 flex items-center justify-between px-8 text-xs font-mono text-gray-400">
               <div className="flex gap-8">
                  <span>LAT: -32.94682</span>
                  <span>LNG: -60.63932</span>
                  <span className="text-nexus-accent">SEC: ROSARIO-CENTRO</span>
               </div>
               <div className="flex gap-4">
                  <span className="flex items-center gap-2"><span className="w-2 h-2 bg-green-500 rounded-full"></span> 42 UNIDADES ONLINE</span>
                  <span className="flex items-center gap-2"><span className="w-2 h-2 bg-yellow-500 rounded-full"></span> 8 ALERTAS ACTIVAS</span>
               </div>
            </div>
         </div>

         {/* Alerts Feed Column */}
         <div className="col-span-12 lg:col-span-4 flex flex-col gap-6 h-[600px]">
            <div className="bg-nexus-900 border border-nexus-700/50 rounded-2xl overflow-hidden flex-1 flex flex-col shadow-xl">
               <div className="p-5 border-b border-nexus-800 flex justify-between items-center bg-nexus-900/50">
                  <h3 className="font-bold text-white flex items-center gap-2">
                     <span className="material-symbols-outlined text-nexus-warning">notifications_active</span>
                     Alertas Prioritarias
                  </h3>
                  <span className="bg-nexus-danger/20 text-nexus-danger border border-nexus-danger/30 text-[10px] font-bold px-2 py-1 rounded-full animate-pulse">EN VIVO</span>
               </div>
               
               <div className="flex-1 overflow-y-auto custom-scrollbar p-0">
                  {RECENT_ALERTS.map((alert, i) => (
                     <div key={i} className="p-4 border-b border-nexus-800/50 hover:bg-nexus-800/30 transition-colors group cursor-pointer relative">
                        <div className={`absolute left-0 top-0 bottom-0 w-1 ${
                           alert.severity === 'critical' ? 'bg-nexus-danger' : 
                           alert.severity === 'high' ? 'bg-nexus-warning' : 'bg-nexus-success'
                        }`}></div>
                        
                        <div className="ml-3">
                           <div className="flex justify-between items-start mb-1">
                              <span className={`text-[10px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded ${
                                 alert.severity === 'critical' ? 'bg-nexus-danger/10 text-nexus-danger' : 
                                 alert.severity === 'high' ? 'bg-nexus-warning/10 text-nexus-warning' : 'bg-nexus-success/10 text-nexus-success'
                              }`}>{alert.severity}</span>
                              <span className="text-[10px] text-gray-500 font-mono">{alert.time}</span>
                           </div>
                           <h4 className="text-sm font-bold text-gray-200 mb-1 group-hover:text-white transition-colors">{alert.title}</h4>
                           <div className="flex items-center text-xs text-gray-500 gap-1">
                              <span className="material-symbols-outlined text-[14px]">location_on</span>
                              {alert.location}
                           </div>
                        </div>
                     </div>
                  ))}
               </div>
               <button 
                  onClick={() => navigate('ops-active')} 
                  className="p-4 text-center text-xs font-bold text-nexus-accent hover:text-white hover:bg-nexus-800 transition-colors border-t border-nexus-800 uppercase tracking-wider"
               >
                  Ver Centro de Alertas
               </button>
            </div>
         </div>

      </div>

      {/* Quick Projects Access */}
      <div className="mt-8">
         <div className="flex justify-between items-center mb-4 px-2">
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
               <span className="material-symbols-outlined text-gray-400">folder_open</span>
               Expedientes Recientes
            </h3>
            <button onClick={() => navigate('projects')} className="text-xs text-nexus-accent hover:text-white font-bold">VER TODOS</button>
         </div>
         
         <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {MOCK_PROJECTS.slice(0,3).map(proj => (
               <div key={proj.id} onClick={() => navigate('workbooks', { projectId: proj.id })} className="bg-nexus-900 border border-nexus-700/50 rounded-xl p-4 hover:border-nexus-500 transition-all cursor-pointer group flex items-center gap-4">
                  <div className="w-12 h-12 rounded-lg bg-nexus-800 flex items-center justify-center text-gray-400 group-hover:text-white group-hover:bg-nexus-700 transition-colors">
                     <span className="material-symbols-outlined">folder</span>
                  </div>
                  <div className="flex-1 min-w-0">
                     <h4 className="text-sm font-bold text-white truncate">{proj.title}</h4>
                     <p className="text-xs text-gray-500 truncate">{proj.type} • {proj.location}</p>
                  </div>
                  <span className="material-symbols-outlined text-gray-600 group-hover:text-nexus-accent group-hover:translate-x-1 transition-all">chevron_right</span>
               </div>
            ))}
         </div>
      </div>

      {/* CREATE OPERATION MODAL */}
      {showCreateOpModal && (
         <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 animate-fade-in">
            <div className="bg-nexus-900 border border-nexus-700 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden relative">
               
               {/* Decorative header line */}
               <div className="h-1 w-full bg-gradient-to-r from-nexus-accent via-purple-500 to-nexus-accent"></div>

               <div className="p-8">
                  <div className="flex justify-between items-start mb-6">
                     <div>
                        <h2 className="text-2xl font-black text-white">Nueva Operación</h2>
                        <p className="text-sm text-gray-400">Configuración inicial del entorno táctico.</p>
                     </div>
                     <div className="w-10 h-10 bg-nexus-800 rounded-full flex items-center justify-center">
                        <span className="material-symbols-outlined text-nexus-accent">add_location</span>
                     </div>
                  </div>

                  <form onSubmit={handleCreateOperation} className="space-y-5">
                     <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Nombre Clave</label>
                        <input 
                           autoFocus
                           type="text" 
                           className="w-full bg-nexus-950 border border-nexus-700 rounded-lg p-3 text-white focus:border-nexus-accent focus:outline-none transition-colors"
                           placeholder="Ej: OPERACIÓN MARTILLO"
                           value={newOpData.title}
                           onChange={e => setNewOpData({...newOpData, title: e.target.value})}
                        />
                     </div>

                     <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Tipo de Delito</label>
                        <select 
                           className="w-full bg-nexus-950 border border-nexus-700 rounded-lg p-3 text-white focus:border-nexus-accent focus:outline-none transition-colors appearance-none"
                           value={newOpData.type}
                           onChange={e => setNewOpData({...newOpData, type: e.target.value})}
                        >
                           <option>Microtráfico</option>
                           <option>Homicidios</option>
                           <option>Lavado de Activos</option>
                           <option>Crimen Organizado</option>
                           <option>Trata de Personas</option>
                        </select>
                     </div>

                     <div>
                        <label className="block text-xs font-bold text-gray-500 uppercase mb-1">Zona / Jurisdicción / Dirección</label>
                        <input 
                           type="text" 
                           className="w-full bg-nexus-950 border border-nexus-700 rounded-lg p-3 text-white focus:border-nexus-accent focus:outline-none transition-colors"
                           placeholder="Ej: Loyola, Santa Fe Capital"
                           value={newOpData.zone}
                           onChange={e => setNewOpData({...newOpData, zone: e.target.value})}
                        />
                        <p className="text-[9px] text-gray-500 mt-1">Se intentará geolocalizar este punto automáticamente.</p>
                     </div>

                     <div className="pt-4 flex gap-3">
                        <button 
                           type="button" 
                           onClick={() => setShowCreateOpModal(false)}
                           className="flex-1 py-3 bg-nexus-800 hover:bg-nexus-700 text-gray-300 rounded-lg font-bold text-sm transition-colors"
                        >
                           Cancelar
                        </button>
                        <button 
                           type="submit"
                           disabled={!newOpData.title || !newOpData.zone || isGeocoding}
                           className="flex-1 py-3 bg-nexus-accent hover:bg-blue-600 text-white rounded-lg font-bold text-sm shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2"
                        >
                           {isGeocoding ? (
                              <>
                                 <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                                 Triangulando...
                              </>
                           ) : 'Iniciar Mapa'}
                        </button>
                     </div>
                  </form>
               </div>
            </div>
         </div>
      )}

    </div>
  );
};
