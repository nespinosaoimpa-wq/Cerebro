import React, { useState } from 'react';
import { MOCK_INTEGRATIONS, MOCK_WORKFLOWS } from '../constants';
import { Workflow, Integration, WorkflowStep } from '../types';

export const AutomationView: React.FC = () => {
  const [integrations, setIntegrations] = useState<Integration[]>(MOCK_INTEGRATIONS);
  const [workflows, setWorkflows] = useState<Workflow[]>(MOCK_WORKFLOWS);
  const [selectedWorkflow, setSelectedWorkflow] = useState<Workflow | null>(MOCK_WORKFLOWS[0]);
  const [isEditing, setIsEditing] = useState(false);

  // Toggle Workflow Status
  const toggleWorkflowStatus = (id: string) => {
    setWorkflows(prev => prev.map(w => 
      w.id === id ? { ...w, status: w.status === 'active' ? 'paused' : 'active' } : w
    ));
    if (selectedWorkflow?.id === id) {
      setSelectedWorkflow(prev => prev ? { ...prev, status: prev.status === 'active' ? 'paused' : 'active' } : null);
    }
  };

  const getServiceColor = (service: string) => {
    switch(service) {
      case 'sheets': return 'text-green-500 border-green-500/50 bg-green-500/10';
      case 'drive': return 'text-blue-500 border-blue-500/50 bg-blue-500/10';
      case 'maps': return 'text-red-500 border-red-500/50 bg-red-500/10';
      case 'whatsapp': return 'text-teal-400 border-teal-400/50 bg-teal-400/10';
      case 'ai_parser': return 'text-purple-400 border-purple-400/50 bg-purple-400/10';
      default: return 'text-gray-400 border-gray-700 bg-gray-800';
    }
  };

  const handleAddStep = () => {
    if (!selectedWorkflow) return;
    const newStep: WorkflowStep = {
      id: `s-${Date.now()}`,
      type: 'action',
      service: 'whatsapp',
      title: 'Nueva Acción',
      config: 'Configurar...',
      icon: 'add_circle'
    };
    const updatedWorkflow = { ...selectedWorkflow, steps: [...selectedWorkflow.steps, newStep] };
    setSelectedWorkflow(updatedWorkflow);
    // Update master list
    setWorkflows(prev => prev.map(w => w.id === updatedWorkflow.id ? updatedWorkflow : w));
  };

  return (
    <div className="h-full flex overflow-hidden">
      
      {/* LEFT SIDEBAR: Workflow List */}
      <div className="w-80 bg-nexus-900 border-r border-nexus-700 flex flex-col z-10">
        <div className="p-4 border-b border-nexus-700 bg-nexus-800/50">
          <h2 className="text-lg font-bold text-white flex items-center gap-2">
            <span className="material-symbols-outlined text-nexus-accent">account_tree</span>
            Mis Flujos
          </h2>
          <button className="mt-3 w-full py-2 bg-nexus-accent hover:bg-blue-600 text-white rounded-lg text-sm font-bold shadow-lg transition-colors flex items-center justify-center gap-2">
            <span className="material-symbols-outlined">add</span>
            Crear Flujo
          </button>
        </div>

        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-2">
          {workflows.map(wf => (
            <div 
              key={wf.id}
              onClick={() => setSelectedWorkflow(wf)}
              className={`p-3 rounded-xl border cursor-pointer transition-all ${
                selectedWorkflow?.id === wf.id 
                  ? 'bg-nexus-800 border-nexus-accent shadow-lg shadow-nexus-accent/10' 
                  : 'bg-nexus-900 border-transparent hover:bg-nexus-800 hover:border-nexus-700'
              }`}
            >
              <div className="flex justify-between items-start mb-2">
                <h3 className={`font-bold text-sm ${selectedWorkflow?.id === wf.id ? 'text-white' : 'text-gray-300'}`}>
                  {wf.name}
                </h3>
                <div className={`w-2 h-2 rounded-full ${wf.status === 'active' ? 'bg-nexus-success shadow-[0_0_5px_rgba(16,185,129,0.8)]' : 'bg-gray-600'}`}></div>
              </div>
              <p className="text-[10px] text-gray-500 line-clamp-2 mb-3">{wf.description}</p>
              
              {/* Integration Icons Mini */}
              <div className="flex -space-x-1.5">
                {wf.steps.map((step, idx) => (
                  <div key={idx} className={`w-5 h-5 rounded-full border border-nexus-900 flex items-center justify-center text-[10px] bg-nexus-800 text-gray-400`}>
                     <span className="material-symbols-outlined text-[12px]">{step.icon}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        {/* Connection Status Mini */}
        <div className="p-3 border-t border-nexus-700 bg-nexus-900">
           <p className="text-[10px] font-bold text-gray-500 uppercase mb-2">Estado de Servicios</p>
           <div className="flex gap-2 overflow-x-auto custom-scrollbar pb-1">
             {integrations.map(int => (
               <div key={int.id} title={int.name} className={`w-2 h-2 rounded-full flex-shrink-0 ${int.status === 'connected' ? 'bg-nexus-success' : 'bg-red-500'}`}></div>
             ))}
             <span className="text-[10px] text-gray-500 ml-1">Todos Conectados</span>
           </div>
        </div>
      </div>

      {/* MAIN AREA: Visual Flow Builder */}
      <div className="flex-1 bg-nexus-900 relative overflow-hidden flex flex-col">
        {selectedWorkflow ? (
          <>
            {/* Toolbar */}
            <div className="h-16 border-b border-nexus-700 bg-nexus-900/90 backdrop-blur flex items-center justify-between px-6 z-20">
              <div>
                <h1 className="text-xl font-bold text-white flex items-center gap-3">
                  {selectedWorkflow.name}
                  <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold border ${selectedWorkflow.status === 'active' ? 'bg-nexus-success/10 text-nexus-success border-nexus-success/30' : 'bg-gray-700/50 text-gray-400 border-gray-600'}`}>
                    {selectedWorkflow.status}
                  </span>
                </h1>
                <p className="text-xs text-gray-500">Última ejecución: {selectedWorkflow.lastRun} • {selectedWorkflow.runCount} ejecuciones exitosas</p>
              </div>
              
              <div className="flex items-center gap-3">
                 <button 
                   onClick={() => toggleWorkflowStatus(selectedWorkflow.id)}
                   className={`px-4 py-2 rounded-lg text-xs font-bold flex items-center gap-2 border transition-colors ${
                     selectedWorkflow.status === 'active' 
                       ? 'bg-nexus-800 text-white border-nexus-600 hover:bg-nexus-700'
                       : 'bg-nexus-success text-white border-nexus-success hover:bg-green-600'
                   }`}
                 >
                   <span className="material-symbols-outlined text-sm">{selectedWorkflow.status === 'active' ? 'pause' : 'play_arrow'}</span>
                   {selectedWorkflow.status === 'active' ? 'PAUSAR' : 'ACTIVAR'}
                 </button>
                 <button className="p-2 rounded-lg bg-nexus-800 text-gray-400 hover:text-white border border-nexus-700">
                   <span className="material-symbols-outlined">settings</span>
                 </button>
              </div>
            </div>

            {/* Canvas */}
            <div className="flex-1 overflow-y-auto custom-scrollbar p-10 bg-[radial-gradient(#1f2937_1px,transparent_1px)] bg-[size:20px_20px]">
              <div className="max-w-3xl mx-auto space-y-0 relative pb-20">
                
                {/* Vertical Line Connector */}
                <div className="absolute left-8 top-8 bottom-0 w-0.5 bg-nexus-700 z-0"></div>

                {selectedWorkflow.steps.map((step, index) => (
                  <div key={step.id} className="relative z-10 group mb-6">
                    <div className="flex items-start gap-6">
                      
                      {/* Icon Node */}
                      <div className={`
                        w-16 h-16 rounded-2xl flex items-center justify-center border-2 shadow-xl bg-nexus-900 z-10 transition-transform group-hover:scale-110
                        ${getServiceColor(step.service)}
                      `}>
                        <span className="material-symbols-outlined text-3xl">{step.icon}</span>
                      </div>

                      {/* Content Card */}
                      <div className="flex-1 glass-panel p-5 rounded-xl border border-nexus-700 hover:border-nexus-600 transition-colors relative">
                        {/* Step Label */}
                        <div className="absolute -top-3 left-4 px-2 py-0.5 bg-nexus-800 text-[10px] font-mono text-gray-400 uppercase tracking-widest border border-nexus-700 rounded">
                           {index === 0 ? 'Disparador (Trigger)' : `Paso ${index + 1}`}
                        </div>

                        <div className="flex justify-between items-start">
                          <div>
                            <h3 className="text-lg font-bold text-white mb-1">{step.title}</h3>
                            <div className="flex items-center gap-2 text-sm text-gray-400 bg-nexus-900/50 p-2 rounded border border-nexus-800/50 inline-block">
                               <span className="material-symbols-outlined text-xs">tune</span>
                               {step.config}
                            </div>
                          </div>
                          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                             <button className="p-1.5 hover:bg-nexus-700 rounded text-gray-400 hover:text-white" title="Editar">
                               <span className="material-symbols-outlined text-sm">edit</span>
                             </button>
                             <button className="p-1.5 hover:bg-nexus-700 rounded text-gray-400 hover:text-red-400" title="Eliminar">
                               <span className="material-symbols-outlined text-sm">delete</span>
                             </button>
                          </div>
                        </div>

                        {/* Integration specific badges */}
                        {step.service === 'ai_parser' && (
                           <div className="mt-3 flex gap-2">
                              <span className="text-[10px] bg-purple-500/20 text-purple-200 px-2 py-1 rounded border border-purple-500/30 flex items-center gap-1">
                                <span className="material-symbols-outlined text-[10px]">auto_awesome</span>
                                Análisis Inteligente
                              </span>
                           </div>
                        )}
                      </div>
                    </div>
                    
                    {/* Add Connector Button between nodes (Visual Only for now) */}
                    <div className="h-8 flex items-center justify-start pl-[26px]">
                       <div className="w-3 h-3 rounded-full bg-nexus-700 border-2 border-nexus-900"></div>
                    </div>
                  </div>
                ))}

                {/* Add Step Button */}
                <div className="flex items-center gap-6 relative z-10 group cursor-pointer" onClick={handleAddStep}>
                  <div className="w-16 h-16 rounded-2xl flex items-center justify-center border-2 border-dashed border-gray-600 bg-nexus-800/30 text-gray-500 group-hover:text-nexus-accent group-hover:border-nexus-accent transition-colors">
                    <span className="material-symbols-outlined text-3xl">add</span>
                  </div>
                  <div className="text-gray-500 group-hover:text-nexus-accent font-medium text-sm transition-colors">
                    Añadir siguiente paso...
                  </div>
                </div>

              </div>
            </div>
          </>
        ) : (
          <div className="flex flex-col items-center justify-center h-full text-gray-500">
             <span className="material-symbols-outlined text-6xl mb-4 text-nexus-700">account_tree</span>
             <p>Selecciona un flujo para editar</p>
          </div>
        )}
      </div>

    </div>
  );
};