
import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import { ChatMessage, Source, Workbook } from '../types';
import { useGlobalState } from '../components/GlobalState';
import { GoogleGenAI } from "@google/genai";
import { extractTextFromPDF } from '../utils/pdfHelper';

// --- VISUALIZATION COMPONENTS ---

// 1. 3D Interactive Graph (Advanced Physics & Interaction)
interface GraphNode { id: string; label: string; type: 'person' | 'location' | 'org' | 'event'; x: number; y: number; z: number; }
interface GraphLink { source: string; target: string; reason: string; citation: string; }

interface TimelineItem {
  date: string;
  event: string;
  source: string;
  importance: string;
}

// Helper to decode raw PCM from Gemini
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const InteractiveGraph: React.FC<{ data: { nodes: GraphNode[], links: GraphLink[] } }> = ({ data }) => {
  const [nodes, setNodes] = useState(data?.nodes || []);
  const [hoveredNode, setHoveredNode] = useState<string | null>(null);
  
  // Camera & Interaction State
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [rotation, setRotation] = useState({ x: 0, y: 0 });
  
  const [isDraggingCanvas, setIsDraggingCanvas] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  
  const [draggingNodeId, setDraggingNodeId] = useState<string | null>(null);

  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
     if (data?.nodes) {
        setNodes(data.nodes);
     }
  }, [data]);

  // -- Canvas Panning & Rotation --
  const handleCanvasMouseDown = (e: React.MouseEvent) => {
    if (draggingNodeId) return; // Prioritize node dragging
    setIsDraggingCanvas(true);
    setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    // 1. Dragging a Node
    if (draggingNodeId) {
       const container = containerRef.current?.getBoundingClientRect();
       if (!container) return;
       
       const xPct = ((e.clientX - container.left) / container.width) * 100;
       const yPct = ((e.clientY - container.top) / container.height) * 100;

       setNodes(prev => prev.map(n => n.id === draggingNodeId ? { ...n, x: xPct, y: yPct } : n));
       return;
    }

    // 2. Panning Canvas
    if (isDraggingCanvas) {
      setPan({ x: e.clientX - dragStart.x, y: e.clientY - dragStart.y });
    } 
    // 3. Passive Rotation Effect (Parallax)
    else if (containerRef.current) {
      const { width, height } = containerRef.current.getBoundingClientRect();
      const x = e.clientX - (containerRef.current.offsetLeft + width / 2);
      const y = e.clientY - (containerRef.current.offsetTop + height / 2);
      setRotation({ x: -(y / height) * 5, y: (x / width) * 5 });
    }
  };

  const handleMouseUp = () => {
    setIsDraggingCanvas(false);
    setDraggingNodeId(null);
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.stopPropagation();
    setZoom(prev => Math.min(Math.max(prev + (e.deltaY * -0.001), 0.5), 4));
  };

  const handleNodeMouseDown = (e: React.MouseEvent, id: string) => {
     e.stopPropagation(); // Stop canvas drag
     setDraggingNodeId(id);
  };

  return (
    <div 
      className="w-full h-full min-h-[600px] bg-[#050505] rounded-xl overflow-hidden relative border border-nexus-800 cursor-move"
      onMouseDown={handleCanvasMouseDown}
      onMouseMove={handleMouseMove}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
      onWheel={handleWheel}
      ref={containerRef}
    >
      <div className="absolute top-4 right-4 z-50 flex flex-col gap-2 pointer-events-none">
         <div className="bg-nexus-900/80 text-white text-[10px] px-3 py-1.5 rounded backdrop-blur border border-nexus-700 shadow-lg">
            <span className="font-bold text-nexus-accent">CONTROLES:</span> Drag (Mover) • Scroll (Zoom) • Nodo (Arrastrar)
         </div>
      </div>

      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(37,99,235,0.03)_0%,transparent_70%)] pointer-events-none"></div>
      
      <div 
        className="w-full h-full relative transition-transform duration-75 ease-out preserve-3d"
        style={{ 
           transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom}) rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
           transformStyle: 'preserve-3d'
        }}
      >
        <svg className="absolute inset-0 w-full h-full pointer-events-none overflow-visible z-0">
          {data.links?.map((link, i) => {
            const source = nodes.find(n => n.id === link.source);
            const target = nodes.find(n => n.id === link.target);
            if (!source || !target) return null;

            const isHovered = hoveredNode === link.source || hoveredNode === link.target;
            const isDimmed = hoveredNode && !isHovered;
            
            return (
              <line 
                key={i}
                x1={`${source.x}%`} y1={`${source.y}%`} 
                x2={`${target.x}%`} y2={`${target.y}%`} 
                stroke={isHovered ? '#3B82F6' : '#4B5563'} 
                strokeWidth={isHovered ? 2 : 0.5} 
                strokeOpacity={isDimmed ? 0.05 : (isHovered ? 1 : 0.2)}
                className="transition-all duration-300"
              />
            );
          })}
        </svg>

        {nodes?.map((node) => {
          const isHovered = hoveredNode === node.id;
          const isRelated = hoveredNode ? data.links?.some(l => (l.source === hoveredNode && l.target === node.id) || (l.target === hoveredNode && l.source === node.id)) : false;
          const isDimmed = hoveredNode && !isHovered && !isRelated;

          return (
            <div
              key={node.id}
              onMouseEnter={() => setHoveredNode(node.id)}
              onMouseLeave={() => setHoveredNode(null)}
              onMouseDown={(e) => handleNodeMouseDown(e, node.id)}
              className={`absolute transform -translate-x-1/2 -translate-y-1/2 flex flex-col items-center group cursor-pointer z-10 transition-opacity duration-300`}
              style={{ 
                left: `${node.x}%`, 
                top: `${node.y}%`,
                opacity: isDimmed ? 0.1 : 1,
                transform: `translate(-50%, -50%) translateZ(${node.z}px)`
              }}
            >
              <div className={`
                w-12 h-12 rounded-full border-2 flex items-center justify-center shadow-[0_0_30px_rgba(0,0,0,0.5)] backdrop-blur-md transition-all duration-300
                ${isHovered ? 'scale-125 z-50 border-white' : 'hover:scale-110'}
                ${node.type === 'person' ? 'bg-red-900/40 border-red-500 text-red-100' : 
                  node.type === 'location' ? 'bg-green-900/40 border-green-500 text-green-100' :
                  'bg-blue-900/40 border-blue-500 text-blue-100'}
              `}>
                 <span className="material-symbols-outlined text-lg">
                    {node.type === 'person' ? 'person' : node.type === 'location' ? 'location_on' : 'domain'}
                 </span>
              </div>
              <div className={`
                 mt-2 px-3 py-1 bg-black/80 border border-white/10 rounded text-[10px] font-bold text-white whitespace-nowrap pointer-events-none transition-all
                 ${isHovered ? 'opacity-100 scale-110' : 'opacity-70'}
              `}>
                 {node.label}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

// 2. Leaflet Map Component (Enhanced High Quality)
interface MapLocation {
   name: string;
   lat: number;
   lng: number;
   context: string;
   type: 'crime_scene' | 'home' | 'evidence' | 'other';
}

const RealTacticalMap: React.FC<{ locations: MapLocation[] }> = ({ locations }) => {
   const mapRef = useRef<HTMLDivElement>(null);
   const mapInstance = useRef<any>(null);
   const [mapType, setMapType] = useState<'tactical' | 'satellite'>('tactical');

   useEffect(() => {
      if (!mapRef.current || mapInstance.current) return;

      if (window.L) {
         const map = window.L.map(mapRef.current, { zoomControl: false }).setView([-32.94682, -60.63932], 12);
         window.L.control.zoom({ position: 'bottomright' }).addTo(map);
         mapInstance.current = map;
      }
   }, []);

   // Handle Tile Layer Change
   useEffect(() => {
      if (!mapInstance.current) return;
      const map = mapInstance.current;

      // Remove existing tile layers
      map.eachLayer((layer: any) => {
         if (layer instanceof window.L.TileLayer) {
            map.removeLayer(layer);
         }
      });

      if (mapType === 'satellite') {
         // High Quality Satellite (Esri World Imagery)
         window.L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
            attribution: 'Tiles &copy; Esri',
            maxZoom: 19
         }).addTo(map);
         // Add labels overlay
         window.L.tileLayer('https://{s}.basemaps.cartocdn.com/light_only_labels/{z}/{x}/{y}{r}.png', {
            maxZoom: 19,
            opacity: 0.8
         }).addTo(map);
      } else {
         // High Quality Dark Tactical (CartoDB Dark Matter)
         window.L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
            attribution: '&copy; OpenStreetMap &copy; CARTO',
            maxZoom: 19
         }).addTo(map);
      }
   }, [mapType]);

   useEffect(() => {
      if (!mapInstance.current || !locations || locations.length === 0) return;
      const map = mapInstance.current;
      
      // Clear markers but keep tiles
      map.eachLayer((layer: any) => { 
         if (layer instanceof window.L.Marker || layer instanceof window.L.Polyline) map.removeLayer(layer); 
      });

      const bounds = window.L.latLngBounds([]);
      
      const crimeScenes = locations.filter(l => l.type === 'crime_scene');
      const homes = locations.filter(l => l.type === 'home');

      locations.forEach((loc, idx) => {
         if(loc.lat && loc.lng) {
            let iconHtml = '';
            let color = '';
            
            if (loc.type === 'crime_scene') {
               iconHtml = '<span class="material-symbols-outlined text-white text-[18px]">skull</span>';
               color = '#ef4444'; // Red
            } else if (loc.type === 'home') {
               iconHtml = '<span class="material-symbols-outlined text-white text-[18px]">home</span>';
               color = '#3b82f6'; // Blue
            } else {
               iconHtml = '<span class="material-symbols-outlined text-white text-[18px]">location_on</span>';
               color = '#10b981'; // Green
            }

            const customIcon = window.L.divIcon({
               className: 'custom-map-icon',
               html: `<div style="background-color:${color}; width:32px; height:32px; border-radius:50%; display:flex; align-items:center; justify-content:center; border:2px solid white; box-shadow:0 4px 8px rgba(0,0,0,0.5);">${iconHtml}</div>`,
               iconSize: [32, 32],
               iconAnchor: [16, 32],
               popupAnchor: [0, -32]
            });

            const marker = window.L.marker([loc.lat, loc.lng], { icon: customIcon }).addTo(map);
            
            // Rich Popup Content
            const popupContent = `
               <div class="text-xs font-sans p-2 min-w-[200px]">
                  <strong class="block text-[${color}] mb-1 uppercase font-bold text-[10px] tracking-wider">${loc.type.replace('_', ' ')}</strong>
                  <strong class="block text-gray-800 text-sm mb-1">${loc.name}</strong>
                  <p class="text-gray-600 leading-tight">${loc.context}</p>
               </div>
            `;
            
            marker.bindPopup(popupContent);
            bounds.extend([loc.lat, loc.lng]);
         }
      });

      crimeScenes.forEach(scene => {
         homes.forEach(home => {
            if (scene.lat && scene.lng && home.lat && home.lng) {
               const distance = map.distance([scene.lat, scene.lng], [home.lat, home.lng]);
               if (distance < 5000) {
                  const latlngs = [[scene.lat, scene.lng], [home.lat, home.lng]];
                  const polyline = window.L.polyline(latlngs, { color: '#f59e0b', weight: 2, dashArray: '5, 10', opacity: 0.8 }).addTo(map);
                  polyline.bindPopup(`Distancia al hecho: ${(distance/1000).toFixed(2)} km`);
               }
            }
         });
      });

      if (locations.length > 0) map.fitBounds(bounds, { padding: [50, 50] });

   }, [locations]);

   return (
      <div className="h-full flex flex-col bg-nexus-950 relative">
         <div className="absolute top-4 left-4 z-[400] flex flex-col gap-2">
            <div className="bg-nexus-900/90 backdrop-blur text-white px-3 py-2 rounded-lg border border-nexus-700 shadow-xl">
               <h3 className="font-bold flex items-center gap-2 text-sm">
                  <span className="material-symbols-outlined text-nexus-success">pin_drop</span>
                  Contexto Geo-Delictual
               </h3>
               <p className="text-[10px] text-gray-400">Visualización de alta precisión</p>
            </div>
            
            <div className="bg-nexus-900/90 backdrop-blur rounded-lg border border-nexus-700 shadow-xl overflow-hidden flex flex-col">
               <button 
                  onClick={() => setMapType('tactical')}
                  className={`px-3 py-2 text-[10px] font-bold text-left flex items-center gap-2 ${mapType === 'tactical' ? 'bg-nexus-800 text-nexus-accent' : 'text-gray-400 hover:text-white'}`}
               >
                  <span className="material-symbols-outlined text-[14px]">dark_mode</span> Táctico Oscuro
               </button>
               <button 
                  onClick={() => setMapType('satellite')}
                  className={`px-3 py-2 text-[10px] font-bold text-left flex items-center gap-2 ${mapType === 'satellite' ? 'bg-nexus-800 text-nexus-accent' : 'text-gray-400 hover:text-white'}`}
               >
                  <span className="material-symbols-outlined text-[14px]">satellite</span> Satélite HD
               </button>
            </div>
         </div>

         <div className="flex-1 relative">
            <div ref={mapRef} className="absolute inset-0 z-0 bg-gray-900" />
            <style>{`
               .leaflet-popup-content-wrapper { background: white; color: #1f2937; border-radius: 8px; padding: 0; overflow: hidden; }
               .leaflet-popup-content { margin: 0 !important; width: 100% !important; }
            `}</style>
         </div>
      </div>
   );
};

// 3. Data Tables
const DataTables: React.FC<{ data: { columns: string[], rows: string[][] } }> = ({ data }) => {
   return (
      <div className="h-full bg-nexus-950 p-8 overflow-y-auto custom-scrollbar">
         <div className="max-w-5xl mx-auto">
            <div className="flex items-center justify-between mb-6">
               <h2 className="text-2xl font-bold text-white flex items-center gap-2">
                  <span className="material-symbols-outlined text-nexus-accent">table_chart</span>
                  Extracción Estructurada
               </h2>
               <button className="px-3 py-1.5 bg-nexus-800 hover:bg-nexus-700 rounded text-xs text-white border border-nexus-600 flex items-center gap-2">
                  <span className="material-symbols-outlined text-sm">download</span> CSV
               </button>
            </div>
            
            <div className="bg-nexus-900 border border-nexus-700 rounded-xl overflow-hidden shadow-2xl">
               <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                     <thead>
                        <tr className="bg-nexus-800 text-gray-300 text-xs uppercase tracking-wider border-b border-nexus-700">
                           {data.columns?.map((col, i) => (
                              <th key={i} className="p-4 font-bold border-r border-nexus-700 last:border-0">{col}</th>
                           ))}
                        </tr>
                     </thead>
                     <tbody className="divide-y divide-nexus-800 text-sm text-gray-300">
                        {data.rows?.map((row, i) => (
                           <tr key={i} className="hover:bg-nexus-800/50 transition-colors odd:bg-nexus-900 even:bg-nexus-900/50">
                              {row?.map((cell, j) => (
                                 <td key={j} className="p-4 border-r border-nexus-800 last:border-0 align-top">
                                    {cell}
                                 </td>
                              ))}
                           </tr>
                        ))}
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
      </div>
   );
};

// 4. NotebookLM Advanced Slides
interface Slide {
   layout: 'title' | 'split' | 'chart' | 'quote';
   title: string;
   content: string; // Bullet points joined by \n
   visualData?: { label: string; value: number }[]; // For chart layout
   imageUrl?: string; // Placeholder for images
}

const PresentationSlides: React.FC<{ slides: Slide[], onGenerateVisual: (slideIndex: number, context: string) => void }> = ({ slides, onGenerateVisual }) => {
   const [currentSlide, setCurrentSlide] = useState(0);

   const nextSlide = () => setCurrentSlide(prev => Math.min(prev + 1, (slides?.length || 1) - 1));
   const prevSlide = () => setCurrentSlide(prev => Math.max(0, prev - 1));

   const renderContent = (slide: Slide, index: number) => {
      if (!slide) return null;
      switch(slide.layout) {
         case 'title':
            return (
               <div className="flex flex-col items-center justify-center h-full text-center">
                  <h1 className="text-6xl font-black text-gray-900 mb-6 uppercase tracking-tighter">{slide.title}</h1>
                  <div className="w-24 h-2 bg-nexus-accent mb-8"></div>
                  <p className="text-2xl text-gray-600 font-serif max-w-2xl">{slide.content}</p>
               </div>
            );
         case 'split':
            return (
               <div className="grid grid-cols-2 gap-12 h-full items-center">
                  <div>
                     <h2 className="text-4xl font-bold text-gray-900 mb-6 leading-tight">{slide.title}</h2>
                     <ul className="space-y-4">
                        {slide.content?.split('\n').map((point, i) => (
                           <li key={i} className="text-lg text-gray-700 flex items-start gap-3">
                              <span className="text-nexus-accent mt-1.5 text-base">●</span>
                              {point}
                           </li>
                        ))}
                     </ul>
                  </div>
                  <div className="h-full bg-gray-100 rounded-xl flex items-center justify-center border-2 border-dashed border-gray-300 relative overflow-hidden group">
                     {slide.imageUrl ? (
                        <img src={slide.imageUrl} className="w-full h-full object-cover" />
                     ) : (
                        <div className="text-center text-gray-400">
                           <span className="material-symbols-outlined text-6xl mb-2">image</span>
                           <p>Evidencia Visual</p>
                           <button 
                              onClick={() => onGenerateVisual(index, `Forensic illustration, high quality, detailed, realistic. Context: ${slide.title} - ${slide.content}`)}
                              className="mt-4 px-4 py-2 bg-nexus-accent text-white rounded shadow text-sm font-bold hover:bg-blue-600 z-20 relative"
                           >
                              Generar Visual IA
                           </button>
                        </div>
                     )}
                     {slide.imageUrl && (
                        <button 
                           onClick={() => onGenerateVisual(index, `Forensic illustration, high quality, detailed, realistic. Context: ${slide.title} - ${slide.content}`)}
                           className="absolute bottom-4 right-4 p-2 bg-black/50 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black"
                           title="Regenerar con Nano Banana"
                        >
                           <span className="material-symbols-outlined">refresh</span>
                        </button>
                     )}
                  </div>
               </div>
            );
         case 'chart':
            return (
               <div className="h-full flex flex-col">
                  <h2 className="text-3xl font-bold text-gray-900 mb-8 border-b pb-4">{slide.title}</h2>
                  <div className="flex-1 flex items-end justify-around pb-12 px-12 gap-8">
                     {slide.visualData?.map((d, i) => (
                        <div key={i} className="flex-1 flex flex-col items-center group">
                           <div className="text-lg font-bold text-nexus-accent mb-2 opacity-0 group-hover:opacity-100 transition-opacity">{d.value}</div>
                           <div 
                              className="w-full bg-nexus-accent rounded-t-lg shadow-lg transition-all duration-1000 ease-out" 
                              style={{ height: `${Math.min(d.value * 2, 300)}px` }}
                           ></div>
                           <div className="mt-4 text-center font-bold text-gray-600 text-sm uppercase">{d.label}</div>
                        </div>
                     ))}
                  </div>
                  <p className="text-center text-gray-500 italic text-sm">{slide.content}</p>
               </div>
            );
         case 'quote':
            return (
               <div className="h-full flex flex-col items-center justify-center px-12 bg-nexus-900 text-white rounded-xl">
                  <span className="material-symbols-outlined text-6xl text-nexus-accent mb-6">format_quote</span>
                  <blockquote className="text-3xl font-serif italic text-center leading-relaxed mb-8">
                     "{slide.content}"
                  </blockquote>
                  <cite className="text-xl font-bold text-nexus-accent uppercase not-italic">— {slide.title}</cite>
               </div>
            );
         default: return null;
      }
   };

   if (!slides || slides.length === 0) {
      return <div className="h-full flex items-center justify-center text-gray-500">Cargando presentación...</div>;
   }

   return (
      <div className="h-full bg-nexus-950 flex flex-col items-center justify-center p-8 relative">
         <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-nexus-900 p-2 rounded-full border border-nexus-700 shadow-xl z-20">
            <button onClick={prevSlide} disabled={currentSlide === 0} className="p-2 rounded-full hover:bg-nexus-800 disabled:opacity-30 text-white">
               <span className="material-symbols-outlined">chevron_left</span>
            </button>
            <span className="text-xs font-mono text-gray-400 w-16 text-center">{currentSlide + 1} / {slides.length}</span>
            <button onClick={nextSlide} disabled={currentSlide === slides.length - 1} className="p-2 rounded-full hover:bg-nexus-800 disabled:opacity-30 text-white">
               <span className="material-symbols-outlined">chevron_right</span>
            </button>
         </div>

         <div className="aspect-video w-full max-w-6xl bg-white rounded-xl shadow-2xl overflow-hidden relative flex flex-col p-16 transition-all duration-500">
            {renderContent(slides[currentSlide], currentSlide)}
            <div className="absolute bottom-4 right-6 text-gray-300 text-[10px] font-mono">CONFIDENCIAL // CEREBRO AC</div>
         </div>
      </div>
   );
};

// 5. Infographic View
const InfographicView: React.FC<{ info: any, onGenerateVisual: () => void, visualUrl: string | null }> = ({ info, onGenerateVisual, visualUrl }) => {
   if (!info) return null;
   return (
      <div className="h-full bg-nexus-950 p-8 overflow-y-auto custom-scrollbar flex justify-center">
         <div className="w-[800px] min-h-[1200px] bg-gradient-to-br from-gray-900 to-black border-4 border-nexus-accent p-8 relative shadow-2xl text-white">
            {/* Header */}
            <div className="text-center mb-12 border-b-2 border-nexus-accent pb-6">
               <h1 className="text-5xl font-black uppercase tracking-tighter mb-2">{info.title || "RESUMEN DE CASO"}</h1>
               <p className="text-nexus-accent font-mono text-xl">REPORTE VISUAL DE INTELIGENCIA</p>
            </div>

            {/* AI Generated Creative Visual */}
            <div className="mb-12 relative w-full h-64 bg-gray-800 rounded-lg overflow-hidden border border-nexus-700 flex items-center justify-center group">
               {visualUrl ? (
                  <img src={visualUrl} className="w-full h-full object-cover" alt="AI Generated Concept" />
               ) : (
                  <div className="text-center">
                     <span className="material-symbols-outlined text-4xl text-gray-600 mb-2">image</span>
                     <p className="text-gray-500 text-sm">Visualización Conceptual</p>
                  </div>
               )}
               <button 
                  onClick={onGenerateVisual}
                  className="absolute bottom-4 right-4 px-3 py-1.5 bg-nexus-accent hover:bg-blue-600 text-white text-xs font-bold rounded shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"
               >
                  {visualUrl ? 'Regenerar (Nano Banana)' : 'Generar Arte Conceptual'}
               </button>
            </div>

            {/* Key Stats Grid */}
            <div className="grid grid-cols-3 gap-6 mb-12">
               {info.stats?.map((stat: any, i: number) => (
                  <div key={i} className="bg-nexus-800/50 p-6 text-center border border-nexus-700 rounded-lg">
                     <div className="text-4xl font-black text-white mb-2">{stat.value}</div>
                     <div className="text-xs font-bold text-nexus-accent uppercase tracking-widest">{stat.label}</div>
                  </div>
               ))}
            </div>

            {/* Central Timeline */}
            <div className="relative border-l-4 border-white/10 ml-8 pl-8 space-y-12 mb-12">
               {info.timeline?.map((item: any, i: number) => (
                  <div key={i} className="relative">
                     <div className="absolute -left-[42px] top-0 w-6 h-6 bg-nexus-accent rounded-full border-4 border-black"></div>
                     <h3 className="text-xl font-bold text-white mb-1">{item.date}</h3>
                     <p className="text-gray-400 leading-relaxed">{item.desc}</p>
                  </div>
               ))}
            </div>

            {/* Entity Network (Visual Representation) */}
            <div className="bg-nexus-900 p-6 rounded-xl border border-nexus-700">
               <h3 className="text-center font-bold text-white mb-6 uppercase tracking-widest">Actores Principales</h3>
               <div className="flex justify-around items-center">
                  {info.entities?.map((ent: any, i: number) => (
                     <div key={i} className="flex flex-col items-center">
                        <div className="w-20 h-20 rounded-full bg-gray-800 border-2 border-white flex items-center justify-center mb-3">
                           <span className="material-symbols-outlined text-3xl text-gray-400">person</span>
                        </div>
                        <span className="font-bold text-sm">{ent.name}</span>
                        <span className="text-xs text-nexus-accent">{ent.role}</span>
                     </div>
                  ))}
               </div>
            </div>

            {/* Footer */}
            <div className="absolute bottom-4 left-0 w-full text-center text-gray-600 text-[10px] font-mono uppercase">
               Generado por CerebroAC AI • Documento Interno
            </div>
         </div>
      </div>
   );
};

// 6. Forensic Timeline
const ForensicTimeline: React.FC<{ events: TimelineItem[] }> = ({ events }) => {
   return (
      <div className="h-full bg-nexus-950 p-8 overflow-y-auto custom-scrollbar">
         <div className="max-w-4xl mx-auto">
            <h2 className="text-2xl font-bold text-white mb-8 flex items-center gap-2">
               <span className="material-symbols-outlined text-nexus-accent">timeline</span>
               Cronología Forense
            </h2>
            <div className="relative border-l-2 border-nexus-700 ml-4 space-y-8 pb-12">
               {events?.map((evt, i) => (
                  <div key={i} className="relative pl-8 group">
                     <div className={`
                        absolute -left-[9px] top-1 w-4 h-4 rounded-full border-2 border-nexus-950 transition-all duration-300
                        ${(evt.importance && (evt.importance.toLowerCase() === 'high' || evt.importance.toLowerCase() === 'critical')) ? 'bg-nexus-danger scale-125' : 'bg-nexus-accent'}
                        group-hover:scale-150
                     `}></div>
                     <div className="glass-panel p-4 rounded-xl border border-nexus-700 bg-nexus-900/40 hover:bg-nexus-800/60 transition-colors">
                        <div className="flex justify-between items-start mb-2">
                           <span className="text-nexus-accent font-mono text-sm font-bold">{evt.date}</span>
                           <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                              (evt.importance && (evt.importance.toLowerCase() === 'high' || evt.importance.toLowerCase() === 'critical')) ? 'bg-red-500/20 text-red-400' : 'bg-blue-500/20 text-blue-400'
                           }`}>
                              {evt.importance || 'Info'}
                           </span>
                        </div>
                        <p className="text-white font-medium mb-2">{evt.event}</p>
                        <div className="text-xs text-gray-500 flex items-center gap-1">
                           <span className="material-symbols-outlined text-[12px]">source</span>
                           Fuente: {evt.source}
                        </div>
                     </div>
                  </div>
               ))}
            </div>
         </div>
      </div>
   );
};

// --- MAIN CONTROLLER ---

export const CaseWorkbookView: React.FC = () => {
  const { addNotification, navigationParams, workbooks, addWorkbook, updateWorkbook, navigate } = useGlobalState();
  const [activeWorkbookId, setActiveWorkbookId] = useState<string | null>(null);
  
  // States
  const [isProcessing, setIsProcessing] = useState(false);
  const [processingStatus, setProcessingStatus] = useState<string>('');
  const [activeTool, setActiveTool] = useState<'chat' | 'graph' | 'timeline' | 'audio' | 'map' | 'report' | 'match' | 'table' | 'slides' | 'infographic'>('chat');
  const [chatInput, setChatInput] = useState('');
  
  // Data Containers
  const [graphData, setGraphData] = useState<{ nodes: GraphNode[], links: GraphLink[] } | null>(null);
  const [timelineData, setTimelineData] = useState<TimelineItem[] | null>(null);
  const [mapData, setMapData] = useState<MapLocation[] | null>(null);
  const [reportData, setReportData] = useState<string | null>(null);
  const [matchesData, setMatchesData] = useState<any[] | null>(null);
  const [tableData, setTableData] = useState<any | null>(null);
  const [slidesData, setSlidesData] = useState<Slide[] | null>(null);
  const [infographicData, setInfographicData] = useState<any | null>(null);
  const [infographicImage, setInfographicImage] = useState<string | null>(null);

  // Audio State
  const [audioBuffer, setAudioBuffer] = useState<AudioBuffer | null>(null);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const audioSourceRef = useRef<AudioBufferSourceNode | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const activeWorkbook = useMemo(() => 
     workbooks.find(w => w.id === activeWorkbookId) || (workbooks.length > 0 ? workbooks[0] : null)
  , [workbooks, activeWorkbookId]);

  // --- INITIALIZATION ---
  useEffect(() => {
    // Priority 1: Direct workbook ID from navigation (e.g. from Ingestion View)
    if (navigationParams?.workbookId) {
       setActiveWorkbookId(navigationParams.workbookId);
    } 
    // Priority 2: Project ID to find associated workbook
    else if (navigationParams?.projectId) {
      const existing = workbooks.find(w => w.caseId === navigationParams.projectId);
      if (existing) setActiveWorkbookId(existing.id);
      else {
        const newWb: Workbook = {
          id: `wb-${Date.now()}`,
          title: navigationParams.projectTitle || 'Nuevo Cuaderno',
          caseId: navigationParams.projectId,
          sources: [], notes: [], chatHistory: []
        };
        addWorkbook(newWb);
        setActiveWorkbookId(newWb.id);
      }
    } 
    // Priority 3: Default to first available if none selected
    else if (!activeWorkbookId && workbooks.length > 0) {
       setActiveWorkbookId(workbooks[0].id);
    }
  }, [navigationParams]); 

  // --- FILE UPLOAD ---
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files || e.target.files.length === 0 || !activeWorkbook) return;
    const files = Array.from(e.target.files) as File[];

    setIsProcessing(true);
    setProcessingStatus(`Iniciando carga de ${files.length} archivo(s)...`);

    const tempFiles: Source[] = files.map(file => ({
        id: `temp-${Date.now()}-${file.name.replace(/\s/g, '')}`,
        title: file.name,
        type: file.name.toLowerCase().endsWith('pdf') ? 'pdf' : 'text',
        contentSummary: 'Leyendo contenido...',
        uploadDate: new Date().toLocaleDateString(),
        citations: 0,
        rawText: '' 
    }));

    let currentSources = [...activeWorkbook.sources, ...tempFiles];
    updateWorkbook(activeWorkbook.id, { sources: currentSources });

    let combinedTextForSummary = "";

    for (let i = 0; i < files.length; i++) {
        const file = files[i];
        const tempId = tempFiles[i].id;
        setProcessingStatus(`Extrayendo texto de: ${file.name}`);
        let extractedText = "";
        try {
            if (file.type === 'application/pdf' || file.name.endsWith('.pdf')) {
                extractedText = await extractTextFromPDF(file);
            } else {
                extractedText = await file.text();
            }
        } catch (err) {
            extractedText = `Error de lectura.`;
        }
        const processedFile: Source = { ...tempFiles[i], id: `src-${Date.now()}-${i}`, contentSummary: "Procesado", rawText: extractedText };
        currentSources = currentSources.map(s => s.id === tempId ? processedFile : s);
        updateWorkbook(activeWorkbook.id, { sources: currentSources });
        if (extractedText.length > 100) combinedTextForSummary += `\nDOC: ${file.name}\n${extractedText.substring(0, 5000)}\n`;
    }

    if (combinedTextForSummary.length > 50) {
        setProcessingStatus('Nexus AI: Analizando evidencia...');
        try {
            const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
            const summaryResponse = await ai.models.generateContent({
                model: 'gemini-3-flash-preview',
                contents: `Analista Intel. Resume. TEXTO: ${combinedTextForSummary}`
            });
            const aiMsg: ChatMessage = {
                id: `ai-sum-${Date.now()}`, role: 'ai', content: summaryResponse.text, timestamp: new Date(), sources: tempFiles.map(s => s.title)
            };
            updateWorkbook(activeWorkbook.id, { chatHistory: activeWorkbook.chatHistory ? [...activeWorkbook.chatHistory, aiMsg] : [aiMsg] });
        } catch (aiErr) { console.warn(aiErr); }
    }
    setIsProcessing(false);
    setProcessingStatus('');
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const getContext = () => {
      let context = "";
      activeWorkbook?.sources.forEach(src => { if(src.rawText) context += `\nFUENTE (${src.title}):\n${src.rawText.substring(0, 15000)}`; });
      return context;
  };

  // --- IMAGE GENERATION HELPER (Nano Banana) ---
  const generateCreativeVisual = async (prompt: string): Promise<string | null> => {
     try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
           model: 'gemini-2.5-flash-image', // Nano Banana series for fast/creative images
           contents: { parts: [{ text: `Cinematic, photorealistic, 8k resolution, detailed texture, forensic style. Topic: ${prompt}` }] },
        });
        
        // Extract Image
        for (const part of response.candidates?.[0]?.content?.parts || []) {
           if (part.inlineData) {
              return `data:image/png;base64,${part.inlineData.data}`;
           }
        }
        return null;
     } catch (e) {
        console.error("Image gen error", e);
        return null;
     }
  };

  // --- TOOLS GENERATORS ---

  const generateGraph = async () => {
     if(!activeWorkbook) return;
     setActiveTool('graph');
     if(graphData) return;
     setIsProcessing(true);
     setProcessingStatus('Construyendo grafo...');
     try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
           model: 'gemini-3-flash-preview',
           contents: `Genera JSON { "nodes": [{"id","label","type"}], "links": [{"source","target","reason","citation"}] } de: ${getContext()}. Asegura IDs consistentes.`,
           config: { responseMimeType: "application/json" }
        });
        const data = JSON.parse(response.text);
        if (data.nodes) {
            const nodes3D = data.nodes.map((n: any) => ({ ...n, x: Math.random()*80 + 10, y: Math.random()*80 + 10, z: Math.random()*100 - 50 }));
            setGraphData({ nodes: nodes3D, links: data.links });
        }
     } catch (e) { addNotification('error', 'Error generando grafo'); } finally { setIsProcessing(false); }
  };

  const generateGeoMap = async () => {
     setActiveTool('map');
     if(mapData) return;
     setIsProcessing(true);
     setProcessingStatus('Geolocalizando con alta precisión...');
     try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
           model: 'gemini-3-flash-preview',
           contents: `Extrae ubicaciones del texto.
           Diferencia entre: Lugar del hecho (crime_scene), Domicilio Víctima/Imputado (home), Otros (evidence).
           INSTRUCCION CRITICA DE PRECISION:
           1. Analiza el texto para identificar la Ciudad principal (ej: Rosario, Santa Fe, Buenos Aires). Si no se menciona, asume Rosario, Argentina.
           2. Para cada ubicación extraída, estima coordenadas lat/lng NUMÉRICAS PRECISAS (Decimal degrees) que caigan DENTRO de esa ciudad. No inventes coordenadas fuera de la zona urbana.
           3. Devuelve JSON: [{ "name": "Dirección", "lat": number, "lng": number, "context": "Descripción", "type": "crime_scene"|"home"|"evidence" }].
           Texto: ${getContext()}`,
           config: { responseMimeType: "application/json" }
        });
        const data = JSON.parse(response.text);
        setMapData(Array.isArray(data) ? data : []);
     } catch(e) { addNotification('error', 'Error en mapeo'); } finally { setIsProcessing(false); }
  };

  const generateSlides = async () => {
     setActiveTool('slides');
     if(slidesData) return;
     setIsProcessing(true);
     setProcessingStatus('Diseñando presentación visual...');
     try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
           model: 'gemini-3-flash-preview',
           contents: `Crea una presentación de 5 diapositivas estilo NotebookLM (Visual y Estructurada).
           Devuelve JSON Array de Objetos: 
           [
             { 
               "layout": "title" | "split" | "chart" | "quote", 
               "title": "Titulo Slide", 
               "content": "Texto descriptivo", 
               "visualData": [{"label": "Enero", "value": 10}, ...] (Solo si layout=chart)
             }
           ]
           Texto: ${getContext()}`,
           config: { responseMimeType: "application/json" }
        });
        const data = JSON.parse(response.text);
        setSlidesData(Array.isArray(data) ? data : []);
     } catch(e) { addNotification('error', 'Error generando diapositivas'); } finally { setIsProcessing(false); }
  };

  const handleSlideVisualGeneration = async (index: number, context: string) => {
     setIsProcessing(true);
     setProcessingStatus('Generando visual creativo con Nano Banana...');
     const imageUrl = await generateCreativeVisual(context);
     if (imageUrl && slidesData) {
        const newSlides = [...slidesData];
        newSlides[index].imageUrl = imageUrl;
        setSlidesData(newSlides);
        addNotification('success', 'Visual generado correctamente.');
     }
     setIsProcessing(false);
  };

  const generateInfographic = async () => {
     setActiveTool('infographic');
     if(infographicData) return;
     setIsProcessing(true);
     setProcessingStatus('Diseñando infografía...');
     try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
           model: 'gemini-3-flash-preview',
           contents: `Crea estructura para una infografía poster del caso.
           JSON: {
             "title": "Titulo Caso",
             "stats": [{"label": "Detenidos", "value": "4"}, ...],
             "timeline": [{"date": "Fecha", "desc": "Evento corto"}, ...],
             "entities": [{"name": "Nombre", "role": "Rol"}]
           }
           Texto: ${getContext()}`,
           config: { responseMimeType: "application/json" }
        });
        const data = JSON.parse(response.text);
        setInfographicData(data);
     } catch(e) { addNotification('error', 'Error generando infografía'); } finally { setIsProcessing(false); }
  };

  const handleInfographicVisualGeneration = async () => {
     if(!infographicData) return;
     setIsProcessing(true);
     setProcessingStatus('Creando arte conceptual con Nano Banana...');
     const imageUrl = await generateCreativeVisual(`Concept art for police investigation case: ${infographicData.title}. Noir style, data visualization elements.`);
     if (imageUrl) {
        setInfographicImage(imageUrl);
        addNotification('success', 'Arte de infografía generado.');
     }
     setIsProcessing(false);
  };

  const generateDeepReport = async () => {
     setActiveTool('report');
     if(reportData) return;
     setIsProcessing(true);
     setProcessingStatus('Redactando informe oficial...');
     try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
           model: 'gemini-3-pro-preview',
           contents: `Escribe un informe de inteligencia forense MUY detallado, formal y bien estructurado en Markdown. 
           Usa encabezados claros, negritas para nombres y fechas.
           Secciones: Encabezado Oficial, Resumen Ejecutivo, Análisis de Vínculos, Cronología Detallada, Hipótesis Investigativa, Conclusiones y Recomendaciones Tácticas.
           Basado en: ${getContext()}`
        });
        setReportData(response.text);
     } catch(e) { addNotification('error', 'Error en reporte'); } finally { setIsProcessing(false); }
  };

  const generateAudioBriefing = async () => {
     if(!activeWorkbook) return;
     setActiveTool('audio');
     if(audioBuffer) return; 

     setIsProcessing(true);
     setProcessingStatus('Generando guion y voz neural...');
     try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const scriptResp = await ai.models.generateContent({
           model: 'gemini-3-flash-preview',
           contents: `Escribe un guion de podcast de investigación policial (estilo True Crime) de 2 minutos sobre esto: ${getContext().substring(0,8000)}`
        });
        
        const audioResp = await ai.models.generateContent({
           model: 'gemini-2.5-flash-preview-tts',
           contents: { parts: [{ text: scriptResp.text }] },
           config: { responseModalities: ['AUDIO'], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } } }
        });

        const base64 = audioResp.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        if(base64) {
             const binaryString = atob(base64);
             const len = binaryString.length;
             const bytes = new Uint8Array(len);
             for (let i = 0; i < len; i++) bytes[i] = binaryString.charCodeAt(i);
             const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
             const buffer = await decodeAudioData(bytes, ctx, 24000, 1);
             setAudioBuffer(buffer);
             audioContextRef.current = ctx;
             addNotification('success', 'Audio generado. Listo para reproducir.');
        } else {
            throw new Error("No audio data received");
        }
     } catch (e) { 
         console.error(e); 
         addNotification('error', 'Error generando audio. Verifique cuota o conexión.'); 
     } finally { setIsProcessing(false); }
  };

  const toggleAudio = () => {
     if (!audioBuffer || !audioContextRef.current) return;
     if (audioContextRef.current.state === 'suspended') audioContextRef.current.resume();
     if (isPlayingAudio) {
        audioSourceRef.current?.stop();
        setIsPlayingAudio(false);
     } else {
        const source = audioContextRef.current.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(audioContextRef.current.destination);
        source.onended = () => setIsPlayingAudio(false);
        source.start();
        audioSourceRef.current = source;
        setIsPlayingAudio(true);
     }
  };

  const generateTimeline = async () => { 
     setActiveTool('timeline'); if(timelineData) return; setIsProcessing(true);
     try { const ai = new GoogleGenAI({apiKey: process.env.API_KEY}); 
     const r = await ai.models.generateContent({model:'gemini-3-flash-preview', contents:`Cronología JSON {events:[{date,event,source,importance}]} de: ${getContext()}`, config:{responseMimeType:'application/json'}});
     const parsed = JSON.parse(r.text);
     setTimelineData(parsed.events || []); } catch(e){} finally {setIsProcessing(false);}
  };
  const generateTable = async () => {
     setActiveTool('table'); if(tableData) return; setIsProcessing(true);
     try { const ai = new GoogleGenAI({apiKey: process.env.API_KEY});
     const r = await ai.models.generateContent({model:'gemini-3-flash-preview', contents:`Tabla JSON {columns:[], rows:[[]]} de: ${getContext()}`, config:{responseMimeType:'application/json'}});
     setTableData(JSON.parse(r.text)); } catch(e){} finally {setIsProcessing(false);}
  };

  const projectToTacticalMap = () => {
      if (mapData && mapData.length > 0) {
          navigate('map', { importedLocations: mapData });
          addNotification('success', 'Ubicaciones enviadas al Mapa Táctico.');
      } else {
          addNotification('warning', 'No hay ubicaciones generadas para proyectar.');
      }
  };

  if (!activeWorkbook) return <div className="h-full flex items-center justify-center text-gray-500">Cargando...</div>;

  return (
    <div className="flex h-full bg-nexus-950 relative">
      
      {/* LEFT SIDEBAR: SOURCES */}
      <div className="w-72 border-r border-nexus-800 flex flex-col bg-nexus-900/50 z-20 print:hidden">
        <div className="h-14 border-b border-nexus-800 flex items-center justify-between px-4">
           <h2 className="font-bold text-gray-200 text-sm flex items-center gap-2">
              <span className="material-symbols-outlined text-nexus-accent">folder_zip</span>
              Evidencia
           </h2>
           <button onClick={() => fileInputRef.current?.click()} className="text-nexus-accent hover:text-white" title="Añadir PDF">
              <span className="material-symbols-outlined">add_circle</span>
           </button>
           <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" multiple accept=".pdf,.txt" />
        </div>
        
        <div className="flex-1 overflow-y-auto custom-scrollbar p-2 space-y-2">
           {activeWorkbook.sources.length === 0 ? (
              <div className="text-center p-6 text-gray-500">
                 <p className="text-xs">Carpeta vacía.</p>
                 <button onClick={() => fileInputRef.current?.click()} className="text-nexus-accent text-xs underline mt-2">Subir Archivos</button>
              </div>
           ) : (
              activeWorkbook.sources.map(src => (
                 <div key={src.id} className="p-3 rounded border border-nexus-800 bg-nexus-900/30 hover:bg-nexus-800 transition-colors group">
                    <div className="flex items-center gap-2 mb-1">
                       <span className="material-symbols-outlined text-red-400 text-sm">picture_as_pdf</span>
                       <span className="text-xs font-bold text-gray-300 truncate flex-1">{src.title}</span>
                       {src.rawText ? (
                           <span className="w-1.5 h-1.5 bg-green-500 rounded-full" title="Indexado"></span>
                       ) : (
                           <span className="w-1.5 h-1.5 bg-yellow-500 rounded-full animate-pulse" title="Procesando"></span>
                       )}
                    </div>
                    <p className="text-[9px] text-gray-500 line-clamp-2">{src.contentSummary}</p>
                 </div>
              ))
           )}
        </div>
      </div>

      {/* MAIN CONTENT AREA */}
      <div className="flex-1 flex flex-col relative bg-nexus-950">
         
         {/* Top Toolbar */}
         <div className="h-14 border-b border-nexus-800 flex items-center justify-between px-6 bg-nexus-900/80 backdrop-blur z-20 print:hidden">
            <h1 className="font-bold text-white flex items-center gap-2 truncate max-w-xs">
               <span className="material-symbols-outlined text-nexus-accent">topic</span>
               {activeWorkbook.title}
            </h1>
            
            <div className="flex bg-nexus-950 p-1 rounded-lg border border-nexus-800 shadow-sm overflow-x-auto">
               {[
                  { id: 'chat', icon: 'chat', label: 'Chat' },
                  { id: 'graph', icon: 'hub', label: 'Grafo' },
                  { id: 'timeline', icon: 'timeline', label: 'Crono' },
                  { id: 'map', icon: 'map', label: 'Mapa' },
                  { id: 'table', icon: 'table_chart', label: 'Tabla' },
                  { id: 'slides', icon: 'slideshow', label: 'Slides' },
                  { id: 'infographic', icon: 'smart_display', label: 'Infografía' },
                  { id: 'report', icon: 'article', label: 'Informe' },
                  { id: 'audio', icon: 'headphones', label: 'Podcast' },
               ].map(tool => (
                  <button 
                     key={tool.id}
                     onClick={() => {
                        if(tool.id === 'graph') generateGraph();
                        else if(tool.id === 'map') generateGeoMap();
                        else if(tool.id === 'timeline') generateTimeline();
                        else if(tool.id === 'report') generateDeepReport();
                        else if(tool.id === 'audio') generateAudioBriefing();
                        else if(tool.id === 'table') generateTable();
                        else if(tool.id === 'slides') generateSlides();
                        else if(tool.id === 'infographic') generateInfographic();
                        setActiveTool(tool.id as any);
                     }}
                     className={`px-3 py-1.5 rounded text-xs font-bold flex items-center gap-2 whitespace-nowrap transition-all ${
                        activeTool === tool.id ? 'bg-nexus-800 text-white shadow' : 'text-gray-500 hover:text-gray-300'
                     }`}
                  >
                     <span className="material-symbols-outlined text-sm">{tool.icon}</span>
                     {tool.label}
                  </button>
               ))}
            </div>
         </div>

         {/* Content Viewport */}
         <div className="flex-1 overflow-hidden relative bg-grid">
            
            {/* Processing Overlay */}
            {isProcessing && (
               <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-nexus-950/80 backdrop-blur-sm animate-fade-in pointer-events-none">
                  <div className="relative">
                     <div className="w-16 h-16 border-4 border-nexus-accent border-t-transparent rounded-full animate-spin"></div>
                     <div className="absolute inset-0 flex items-center justify-center">
                        <span className="material-symbols-outlined text-nexus-accent animate-pulse">neurology</span>
                     </div>
                  </div>
                  <p className="text-nexus-accent font-mono text-sm mt-4 animate-pulse">{processingStatus}</p>
               </div>
            )}

            {activeTool === 'chat' && (
               <div className="h-full flex flex-col">
                  <div className="flex-1 overflow-y-auto custom-scrollbar p-6 space-y-4">
                     {activeWorkbook.chatHistory?.length === 0 ? (
                        <div className="h-full flex flex-col items-center justify-center opacity-50">
                           <span className="material-symbols-outlined text-6xl text-gray-600 mb-4">upload_file</span>
                           <p className="text-gray-400">Sube archivos PDF para comenzar el análisis.</p>
                        </div>
                     ) : (
                        activeWorkbook.chatHistory?.map(msg => (
                           <div key={msg.id} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                              <div className={`max-w-2xl p-4 rounded-xl text-sm leading-relaxed shadow-md ${msg.role === 'user' ? 'bg-nexus-800 text-white rounded-br-none' : 'bg-nexus-900 border border-nexus-700 text-gray-200 rounded-bl-none'}`}>
                                 {msg.role === 'ai' && <div className="text-[10px] font-bold text-nexus-accent uppercase mb-1 flex items-center gap-1"><span className="material-symbols-outlined text-[12px]">auto_awesome</span> Nexus AI</div>}
                                 <p className="whitespace-pre-wrap">{msg.content}</p>
                              </div>
                           </div>
                        ))
                     )}
                     <div ref={messagesEndRef} />
                  </div>
                  
                  <div className="p-4 border-t border-nexus-800 bg-nexus-900/50">
                     <form 
                        onSubmit={async (e) => {
                           e.preventDefault();
                           if(!chatInput.trim()) return;
                           const newMsg: ChatMessage = { id: Date.now().toString(), role: 'user', content: chatInput, timestamp: new Date() };
                           updateWorkbook(activeWorkbook.id, { chatHistory: [...(activeWorkbook.chatHistory || []), newMsg] });
                           setChatInput('');
                           setIsProcessing(true);
                           try {
                               const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
                               const context = getContext();
                               const chatSession = ai.chats.create({ 
                                   model: 'gemini-3-flash-preview',
                                   config: { systemInstruction: "Eres un analista de inteligencia. Responde basándote estrictamente en las fuentes proporcionadas." }
                               });
                               const result = await chatSession.sendMessage({ message: `${context}\n\nPREGUNTA USUARIO: ${newMsg.content}` });
                               const aiResponse: ChatMessage = { id: `ai-${Date.now()}`, role: 'ai', content: result.text, timestamp: new Date(), sources: activeWorkbook.sources?.map(s => s.title) || [] };
                               const latestChat = activeWorkbook.chatHistory ? [...activeWorkbook.chatHistory, newMsg, aiResponse] : [newMsg, aiResponse];
                               updateWorkbook(activeWorkbook.id, { chatHistory: latestChat });
                           } catch(err) { console.error(err); } finally { setIsProcessing(false); }
                        }} 
                        className="relative"
                     >
                        <input 
                           value={chatInput} 
                           onChange={e => setChatInput(e.target.value)}
                           className="w-full bg-nexus-950 border border-nexus-700 rounded-xl py-3 pl-4 pr-12 text-sm text-white focus:border-nexus-accent focus:outline-none"
                           placeholder="Pregunta sobre la evidencia..." 
                        />
                        <button type="submit" className="absolute right-2 top-2 p-1.5 bg-nexus-accent rounded-lg text-white hover:bg-blue-600">
                           <span className="material-symbols-outlined text-lg">arrow_upward</span>
                        </button>
                     </form>
                  </div>
               </div>
            )}

            {activeTool === 'graph' && (
               graphData ? <InteractiveGraph data={graphData} /> : <div className="h-full flex items-center justify-center text-gray-500">Seleccione "Grafo" para generar la visualización.</div>
            )}

            {activeTool === 'timeline' && (
               timelineData ? <ForensicTimeline events={timelineData} /> : <div className="h-full flex items-center justify-center text-gray-500">Seleccione "Crono" para extraer eventos.</div>
            )}

            {activeTool === 'map' && (
               mapData ? (
                  <div className="relative h-full w-full">
                     <RealTacticalMap locations={mapData} />
                     <div className="absolute top-4 right-4 z-[500]">
                        <button 
                           onClick={projectToTacticalMap}
                           className="bg-nexus-accent hover:bg-blue-600 text-white px-4 py-2 rounded shadow-lg font-bold text-sm flex items-center gap-2 border border-blue-400"
                        >
                           <span className="material-symbols-outlined">map</span>
                           Proyectar en Mapa Táctico Global
                        </button>
                     </div>
                  </div>
               ) : <div className="h-full flex items-center justify-center text-gray-500">Seleccione "Mapa" para extraer geolocalización.</div>
            )}

            {activeTool === 'table' && (
               tableData ? <DataTables data={tableData} /> : <div className="h-full flex items-center justify-center text-gray-500">Seleccione "Tabla" para estructurar datos.</div>
            )}

            {activeTool === 'slides' && (
               slidesData ? <PresentationSlides slides={slidesData} onGenerateVisual={handleSlideVisualGeneration} /> : <div className="h-full flex items-center justify-center text-gray-500">Seleccione "Slides" para generar presentación.</div>
            )}

            {activeTool === 'infographic' && (
               infographicData ? <InfographicView info={infographicData} onGenerateVisual={handleInfographicVisualGeneration} visualUrl={infographicImage} /> : <div className="h-full flex items-center justify-center text-gray-500">Seleccione "Infografía" para generar poster.</div>
            )}

            {activeTool === 'report' && (
               reportData ? (
                  <div className="h-full bg-gray-100 text-black p-8 overflow-y-auto custom-scrollbar flex justify-center">
                     <div className="w-[210mm] min-h-[297mm] bg-white shadow-xl p-12 text-sm font-serif leading-relaxed relative print:w-full print:h-full print:shadow-none">
                        <div className="absolute top-8 right-12 text-red-700 font-bold border-2 border-red-700 px-2 py-1 transform -rotate-12 opacity-80 text-xl tracking-widest uppercase">Confidencial</div>
                        
                        <div className="flex items-center gap-4 border-b-2 border-black pb-4 mb-8">
                           <div className="w-16 h-16 bg-black rounded-full flex items-center justify-center">
                              <span className="material-symbols-outlined text-white text-3xl">local_police</span>
                           </div>
                           <div>
                              <h1 className="text-2xl font-bold uppercase tracking-wide font-sans">Ministerio de Seguridad</h1>
                              <p className="text-xs uppercase tracking-widest font-sans">Dirección de Inteligencia Criminal</p>
                           </div>
                        </div>

                        <div className="whitespace-pre-wrap prose prose-sm max-w-none text-justify">
                           {reportData}
                        </div>

                        <div className="mt-12 pt-8 border-t border-gray-300 flex justify-between text-[10px] font-sans text-gray-500 uppercase">
                           <span>Generado por Sistema CerebroAC</span>
                           <span>{new Date().toLocaleDateString()}</span>
                           <span>Pág 1/1</span>
                        </div>

                        <button 
                           onClick={() => window.print()}
                           className="absolute top-4 right-[-80px] p-3 bg-blue-600 text-white rounded-full shadow-xl hover:bg-blue-700 print:hidden"
                           title="Imprimir / Guardar PDF"
                        >
                           <span className="material-symbols-outlined">print</span>
                        </button>
                     </div>
                  </div>
               ) : <div className="h-full flex items-center justify-center text-gray-500">Seleccione "Informe" para redactar reporte profundo.</div>
            )}

            {activeTool === 'audio' && (
               <div className="flex flex-col items-center justify-center h-full">
                  <div className="w-80 h-80 rounded-full bg-gradient-to-br from-gray-900 to-black border-4 border-nexus-800 shadow-[0_0_50px_rgba(0,0,0,0.5)] flex items-center justify-center relative group">
                     {isPlayingAudio && (
                        <>
                           <div className="absolute inset-0 rounded-full border border-nexus-accent/30 animate-[ping_2s_linear_infinite]"></div>
                           <div className="absolute inset-0 rounded-full border border-nexus-accent/20 animate-[ping_2s_linear_infinite_1s]"></div>
                        </>
                     )}
                     <div className="text-center z-10">
                        <button 
                           onClick={toggleAudio}
                           disabled={!audioBuffer}
                           className="w-24 h-24 bg-nexus-accent text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform disabled:bg-gray-700 disabled:cursor-not-allowed mb-4 mx-auto"
                        >
                           <span className="material-symbols-outlined text-5xl">{isPlayingAudio ? 'pause' : 'play_arrow'}</span>
                        </button>
                        <h3 className="text-xl font-bold text-white tracking-wide">Nexus Audio Briefing</h3>
                        <p className="text-xs text-gray-400 mt-1">IA Narrativa • Voz Neuronal</p>
                        {!audioBuffer && !isProcessing && <p className="text-nexus-warning text-[10px] mt-4">Esperando generación...</p>}
                        {audioBuffer && !isPlayingAudio && <p className="text-nexus-success text-[10px] mt-4">Listo para reproducir</p>}
                     </div>
                  </div>
               </div>
            )}

         </div>
      </div>

    </div>
  );
};
